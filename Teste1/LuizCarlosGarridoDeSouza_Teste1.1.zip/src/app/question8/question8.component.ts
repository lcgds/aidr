import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question8',
  templateUrl: './question8.component.html',
  styleUrls: ['./question8.component.css']
})
export class Question8Component implements OnInit {
  nome: string = '';
  sobrenome: string = '';

  constructor() { }

  ngOnInit(): void {
  }

}
