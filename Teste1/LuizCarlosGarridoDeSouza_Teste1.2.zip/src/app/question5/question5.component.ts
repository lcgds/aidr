import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question5',
  templateUrl: './question5.component.html',
  styleUrls: ['./question5.component.css']
})

export class Question5Component implements OnInit {

  variavel: any;

  constructor() { }

  ngOnInit(): void {
  }

}
